#
# Regular cron jobs for the bmake package
#
0 4	* * *	root	[ -x /usr/bin/bmake_maintenance ] && /usr/bin/bmake_maintenance
