/*
/// *****************************************************************
/// ***                                                 
/// *** BOEING PROPRIETARY, CONFIDENTIAL
/// *** Copyright (C) 2011-05-19T14:03:52.069086Z Boeing. All rights reserved.
/// ***
/// *** All copyrights and other intellectual property rights 
/// *** used or embodied in or in connection with this Software are 
/// *** and shall remain the exclusive property of The Boeing Company
/// ***
/// *** Disclaimer
/// *** BR&TE (Boeing Research & Technology Europe) does not warrant 
/// *** or assume any legal liability or
/// *** responsibility for the accuracy, completeness, fitness or 
/// *** suitability for any particular purpose or conditions of the 
/// *** software disclosed.   
/// ***                                          
/// *** Rev date: 2011-05-19T14:03:52.069086Z                         
/// *** Rev : 4943                         
/// ***                                                 
/// *****************************************************************
*/

#ifndef _BMAKE_TARGET_
#define _BMAKE_TARGET_

#include "bmake.h"

#include <string>
#include <set>
#include <list>
#include <iostream>
#include <libxml++/libxml++.h>
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/path.hpp>

namespace bmake {


class project;
class third_party_dependency;

class BMAKE_EXPORT_IMPORT_POLICY target {
public:
	typedef boost::filesystem::path path;
	typedef xmlpp::Element dom_element;

	target();
	virtual ~target();

	typedef std::string definition;
	typedef std::list<definition> definitions;

	inline const std::string& get_name() const { return _name; }
	inline const project& get_project() const { return *_project; }
	inline project& get_project() { return *_project; }

	inline void set_project(project& p) { _project=&p; }


	typedef std::set<const target*> dependencies;
	typedef std::set<const third_party_dependency*> third_party_dependencies;


	const dependencies& get_dependencies() const { return _dependencies; }
	dependencies get_all_dependencies() const;

	const third_party_dependencies& get_third_party_dependencies() const { return _third_party_dependencies; }
	third_party_dependencies get_all_third_party_dependencies() const;

	bool file_exists(const std::string& file) const;

	typedef std::set<std::string> dirs;
	dirs get_header_dirs(const path&) const;
	dirs get_cpp_dirs(const path&) const;
	std::string to_identif(const std::string&) const;
	std::string to_group(const std::string&) const;


	virtual void write_definitions(std::ostream& os) const;
	bool is_mingw() const;
	bool is_unittest() const;

	void set_unit_test() { _unit_test=true; }
public:
	void put_all_dependencies(dependencies&) const;
	void put_all_third_party_dependencies(third_party_dependencies&) const;

public:
	virtual void write_cmake(const path&) const;

	static target* create(project& parent, const dom_element& e);
	void parse(project&,const dom_element&);

	void resolvedeps();

private:
	std::string _name;
	std::string _title;
	bool _unit_test;

	project* _project;  /// weak

	dependencies _dependencies;

	third_party_dependencies _third_party_dependencies;

	definitions _definitions;

private:
	struct depstr {
		std::string prj;
		std::string tgt;
	};
	typedef std::list<depstr> depstrs;
	depstrs _depstrs;
};



}

#endif
