/*
/// *****************************************************************
/// ***                                                 
/// *** BOEING PROPRIETARY, CONFIDENTIAL
/// *** Copyright (C) 2011-05-19T14:03:52.069086Z Boeing. All rights reserved.
/// ***
/// *** All copyrights and other intellectual property rights 
/// *** used or embodied in or in connection with this Software are 
/// *** and shall remain the exclusive property of The Boeing Company
/// ***
/// *** Disclaimer
/// *** BR&TE (Boeing Research & Technology Europe) does not warrant 
/// *** or assume any legal liability or
/// *** responsibility for the accuracy, completeness, fitness or 
/// *** suitability for any particular purpose or conditions of the 
/// *** software disclosed.   
/// ***                                          
/// *** Rev date: 2011-05-19T14:03:52.069086Z                         
/// *** Rev : 4943                         
/// ***                                                 
/// *****************************************************************
*/

#ifndef BMAKE_H_INCLUDED
#define BMAKE_H_INCLUDED

#if defined(_MSC_VER)
//4251: some class or template needs to have dll-interface to be used by clients of this class 
//no problem when reffers to templates, clients can link succesfully because the class instantiation (the code) is in client side (so no link at all)
//disabling 4251 can hide a problem when this class (which is dll exported) either 1.-expose in non-private sections or 2.-use in inline functions implementations, types witch are not dll exported
# pragma warning ( disable :4251 )
#endif

// windows shared library design require to mine the source code with this ugly litter
// because it precises to expicitely say which symbols one want to be exported
// (when using this header to build the library) or imported (when some other project wants
// to use the classes provided by this library

#ifdef _WIN32
#  ifdef BMAKE_EXPORT_SYMBOLS
#    define BMAKE_EXPORT_IMPORT_POLICY __declspec(dllexport)
#    define BMAKE_EXPORT_IMPORT_POLICY_MSG "	BMAKE: Exporting symbols"
#  else
#	ifdef BMAKE_IMPORT_SYMBOLS
#		define BMAKE_EXPORT_IMPORT_POLICY __declspec(dllimport)
#		 define BMAKE_EXPORT_IMPORT_POLICY_MSG "	BMAKE: Importing symbols"
#	else
#		define BMAKE_EXPORT_IMPORT_POLICY
#		 define BMAKE_EXPORT_IMPORT_POLICY_MSG "	BMAKE: neither importing nor exporting symbols"
#	endif
#  endif
#else
# define BMAKE_EXPORT_IMPORT_POLICY __attribute__ ((visibility("default")))
#endif

#ifndef SHOW_IMPORT_EXPORT_MSG
//#define SHOW_IMPORT_EXPORT_MSG
#endif



#ifdef _WIN32
#ifdef SHOW_IMPORT_EXPORT_MSG
#pragma message (BMAKE_EXPORT_IMPORT_POLICY_MSG)
#endif
#endif


#endif
