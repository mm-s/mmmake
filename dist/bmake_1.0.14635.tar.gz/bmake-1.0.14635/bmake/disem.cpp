#include "disem.h"
typedef bmake::disem c;
const std::string c::major="1";
const std::string c::minor="0";
const std::string c::rev="14635";
