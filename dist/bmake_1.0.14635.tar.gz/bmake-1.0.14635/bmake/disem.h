/*
/// *****************************************************************
/// ***                                                 
/// *** BOEING PROPRIETARY, CONFIDENTIAL
/// *** Copyright (C) 2011-05-19T14:03:52.069086Z Boeing. All rights reserved.
/// ***
/// *** All copyrights and other intellectual property rights 
/// *** used or embodied in or in connection with this Software are 
/// *** and shall remain the exclusive property of The Boeing Company
/// ***
/// *** Disclaimer
/// *** BR&TE (Boeing Research & Technology Europe) does not warrant 
/// *** or assume any legal liability or
/// *** responsibility for the accuracy, completeness, fitness or 
/// *** suitability for any particular purpose or conditions of the 
/// *** software disclosed.   
/// ***                                          
/// *** Rev date: 2011-05-19T14:03:52.069086Z                         
/// *** Rev : 4943                         
/// ***                                                 
/// *****************************************************************
*/

#ifndef BMAKE_DISEM
#define BMAKE_DISEM

#include "bmake.h"
#include <string>
namespace bmake {

struct BMAKE_EXPORT_IMPORT_POLICY disem {
	static const std::string major;
	static const std::string minor;
	static const std::string rev;

	static std::string get_version() { return major + "." + minor + "." + rev; }
};

}




#endif




