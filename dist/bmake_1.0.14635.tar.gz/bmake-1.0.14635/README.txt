Build from sources
------------------

from the package source directory do
CMAKE_MODULE_PATH share/bmake/cmakemodules cmake .

then
make bmake


build debian package
--------------------

from the package source directory do
dpkg-buildpackage


